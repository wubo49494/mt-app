<template>
  <el-container class="layout-default">
    <el-header>
      <my-header/>
    </el-header>

    <el-main>
    </el-main>
  </el-container>
</template>

<script>
import MyHeader from '@/components/public/header/header.vue'

export default {
  components: {
    MyHeader
  }

}
</script>
<style lang="scss">
  body{
  margin: 0;
  padding: 0;
}
body *{
  margin: 0;
  padding: 0;
}
.el-header,.el-main,.el-footer{
    padding: 0;
    overflow: unset;
}
.el-main {
  background-color: #F8F8F8;
}
</style>